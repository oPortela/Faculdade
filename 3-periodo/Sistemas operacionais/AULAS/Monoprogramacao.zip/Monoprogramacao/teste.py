import subprocess

teste = 'C:\Program Files\Google\Chrome\Application\chrome.exe'

subprocess.Popen(teste)